/**
 * PropChain KYC Backend — Manual Admin Review Mode
 *
 * POST /kyc/submit        — user uploads document; validated and queued for admin review
 * GET  /kyc/requests      — admin fetches the full queue (all statuses)
 * POST /kyc/resolve       — admin records the on-chain outcome (approve/reject + txHash)
 * GET  /kyc/status/:addr  — user polls their own queue status
 * GET  /health            — liveness check
 *
 * The queue is in-memory (resets on restart). For production, swap for a real DB.
 * Runs on port 3001. Vite dev-server proxies /api → http://localhost:3001.
 */

import { createServer, IncomingMessage, ServerResponse } from 'http'

const PORT = 3001
const KYC_VERIFIER = (process.env.VITE_KYC_VERIFIER ?? '').toLowerCase()

// ---------------------------------------------------------------------------
// In-memory KYC queue
// ---------------------------------------------------------------------------

interface KycRequest {
  wallet: string
  docType: string
  submittedAt: number
  status: 'pending' | 'approved' | 'rejected'
  txHash?: string
}

const queue = new Map<string, KycRequest>() // wallet.toLowerCase() → request

// ---------------------------------------------------------------------------
// Multipart parser (zero external deps)
// ---------------------------------------------------------------------------

function parseBoundary(ct: string): string | null {
  const m = ct.match(/boundary=([^\s;]+)/)
  return m ? m[1] : null
}

interface MultipartPart { fieldName: string; filename?: string; mimeType: string; data: Buffer }

function parseMultipart(body: Buffer, boundary: string): MultipartPart[] {
  const sep = Buffer.from('--' + boundary)
  const parts: MultipartPart[] = []
  let offset = 0
  while (offset < body.length) {
    const start = body.indexOf(sep, offset)
    if (start === -1) break
    const hs = start + sep.length + 2
    const he = body.indexOf(Buffer.from('\r\n\r\n'), hs)
    if (he === -1) break
    const hdr = body.slice(hs, he).toString()
    const ds = he + 4
    const nb = body.indexOf(sep, ds)
    const de = nb === -1 ? body.length : nb - 2
    const cd = hdr.match(/Content-Disposition:[^\r\n]*name="([^"]+)"/)
    const fn = hdr.match(/filename="([^"]+)"/)
    const ct2 = hdr.match(/Content-Type:\s*([^\r\n]+)/)
    if (cd) parts.push({ fieldName: cd[1], filename: fn?.[1], mimeType: ct2?.[1].trim() ?? 'application/octet-stream', data: body.slice(ds, de) })
    offset = nb === -1 ? body.length : nb
  }
  return parts
}

// ---------------------------------------------------------------------------
// Document validation (magic-byte check)
// ---------------------------------------------------------------------------

function detectFileType(d: Buffer): string | null {
  if (d[0] === 0xff && d[1] === 0xd8 && d[2] === 0xff) return 'image/jpeg'
  if (d[0] === 0x89 && d[1] === 0x50 && d[2] === 0x4e && d[3] === 0x47) return 'image/png'
  if (d[0] === 0x52 && d[1] === 0x49 && d[2] === 0x46 && d[3] === 0x46) return 'image/webp'
  if (d[0] === 0x25 && d[1] === 0x50 && d[2] === 0x44 && d[3] === 0x46) return 'application/pdf'
  return null
}

const ACCEPTED = new Set(['image/jpeg','image/jpg','image/png','image/webp','application/pdf'])

function validateDocument(data: Buffer, declared: string): { ok: boolean; reason?: string } {
  if (data.length < 100)              return { ok: false, reason: 'File too small to be a valid document.' }
  if (data.length > 20 * 1024 * 1024) return { ok: false, reason: 'File exceeds 20 MB limit.' }
  const detected = detectFileType(data)
  if (!detected || !ACCEPTED.has(detected)) return { ok: false, reason: 'Unrecognised format. Upload JPEG, PNG, WebP, or PDF.' }
  const decl = declared.split(';')[0].trim().toLowerCase()
  if (decl && decl !== 'application/octet-stream' && decl !== detected) {
    if (!(decl === 'image/jpg' && detected === 'image/jpeg'))
      return { ok: false, reason: 'Declared MIME type does not match file content.' }
  }
  return { ok: true }
}

// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type' })
  res.end(payload)
}

async function readBody(req: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  for await (const c of req) chunks.push(c as Buffer)
  return Buffer.concat(chunks)
}

// ---------------------------------------------------------------------------
// HTTP server
// ---------------------------------------------------------------------------

createServer(async (req: IncomingMessage, res: ServerResponse) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST,GET,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' })
    res.end(); return
  }

  // Health
  if (req.method === 'GET' && req.url === '/health') {
    sendJson(res, 200, { ok: true, queueSize: queue.size, verifier: KYC_VERIFIER || 'not-set' }); return
  }

  // POST /kyc/submit — user submits document
  if (req.method === 'POST' && req.url === '/kyc/submit') {
    const ct = req.headers['content-type'] ?? ''
    const boundary = parseBoundary(ct)
    if (!boundary) { sendJson(res, 400, { error: 'Expected multipart/form-data' }); return }

    const body = await readBody(req).catch(() => null)
    if (!body) { sendJson(res, 500, { error: 'Failed to read body' }); return }

    const parts = parseMultipart(body, boundary)
    const walletField  = parts.find(p => p.fieldName === 'wallet')
    const docTypeField = parts.find(p => p.fieldName === 'docType')
    const docFile      = parts.find(p => p.fieldName === 'document')

    if (!walletField || !docTypeField || !docFile) {
      sendJson(res, 400, { error: 'Missing required fields' }); return
    }

    const wallet = walletField.data.toString().trim().toLowerCase()
    if (!/^0x[0-9a-f]{40}$/.test(wallet)) { sendJson(res, 400, { error: 'Invalid wallet address' }); return }

    if (queue.get(wallet)?.status === 'approved') {
      sendJson(res, 200, { ok: true, status: 'already_approved' }); return
    }

    const v = validateDocument(docFile.data, docFile.mimeType)
    if (!v.ok) { sendJson(res, 422, { error: v.reason }); return }

    const docType = docTypeField.data.toString().trim()
    queue.set(wallet, { wallet, docType, submittedAt: Date.now(), status: 'pending' })
    console.log(`[KYC] Queued: ${wallet} (${docType}) — ${[...queue.values()].filter(r => r.status === 'pending').length} pending`)

    sendJson(res, 200, { ok: true, status: 'queued', message: 'Document received. An admin will review and approve you on-chain shortly.' })
    return
  }

  // GET /kyc/requests — admin reads queue
  if (req.method === 'GET' && req.url === '/kyc/requests') {
    const requests = [...queue.values()].sort((a, b) => {
      if (a.status === 'pending' && b.status !== 'pending') return -1
      if (a.status !== 'pending' && b.status === 'pending') return 1
      return b.submittedAt - a.submittedAt
    })
    sendJson(res, 200, { ok: true, requests }); return
  }

  // POST /kyc/resolve — admin records outcome
  if (req.method === 'POST' && req.url === '/kyc/resolve') {
    const body = await readBody(req).catch(() => null)
    if (!body) { sendJson(res, 500, { error: 'Failed to read body' }); return }
    let payload: { wallet?: string; status?: string; txHash?: string }
    try { payload = JSON.parse(body.toString()) as typeof payload } catch { sendJson(res, 400, { error: 'Invalid JSON' }); return }
    const { wallet, status, txHash } = payload
    if (!wallet || !status) { sendJson(res, 400, { error: 'Missing wallet or status' }); return }
    const key = wallet.toLowerCase()
    const existing = queue.get(key)
    if (!existing) { sendJson(res, 404, { error: 'Request not found' }); return }
    queue.set(key, { ...existing, status: status as 'approved' | 'rejected', txHash })
    console.log(`[KYC] Resolved: ${key} → ${status}`)
    sendJson(res, 200, { ok: true }); return
  }

  // GET /kyc/status/:addr — user polls their own status
  const sm = req.method === 'GET' && req.url?.match(/^\/kyc\/status\/(0x[0-9a-fA-F]{40})$/)
  if (sm) {
    const entry = queue.get(sm[1].toLowerCase())
    sendJson(res, 200, { ok: true, status: entry?.status ?? 'not_submitted' }); return
  }

  sendJson(res, 404, { error: 'Not found' })
}).listen(PORT, () => {
  console.log(`\n[KYC] Backend listening on http://localhost:${PORT}`)
  console.log('[KYC] Mode: MANUAL — admin reviews via the Admin tab in the app')
})
