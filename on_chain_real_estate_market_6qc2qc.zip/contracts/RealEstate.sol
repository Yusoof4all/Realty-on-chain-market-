// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";

contract RealEstate is Ownable, ReentrancyGuard, EIP712 {
    using SafeERC20 for IERC20;

    uint256 private constant BASIS_POINTS = 10_000;
    uint256 private constant PURCHASE_FEE_BPS = 150; // 1.5%
    uint256 private constant RENT_FEE_BPS = 50; // 0.5%
    uint256 private constant PURCHASE_DISPUTE_WINDOW = 30 days;
    uint8 private constant KYC_LEVEL_BASIC = 1;
    uint8 private constant KYC_LEVEL_FULL = 2;
    uint8 private constant MIN_REVIEW_SCORE = 1;
    uint8 private constant MAX_REVIEW_SCORE = 5;
    bytes32 private constant KYC_TYPEHASH = keccak256(
        "KycAuthorization(address user,uint8 level,uint256 nonce,uint256 expiry)"
    );

    enum EscrowState {
        PENDING,
        FUNDED,
        INSPECTION,
        COMPLETED,
        DISPUTED,
        REFUNDED
    }

    enum RentState {
        PENDING,
        DEPOSIT_PAID,
        ACTIVE,
        TERMINATED,
        DISPUTED
    }

    struct UserProfile {
        bool isKyced;
        uint8 kycLevel; // 0=none,1=basic,2=full
        uint16 reputationScore; // 0-500
        uint256 totalTransactions;
        uint256 disputeCount;
        bool isBanned;
        uint256 reviewCount;
    }

    struct Listing {
        uint256 listingId;
        address owner;
        string title;
        string location;
        string propertyType;
        uint256 priceUsdc;
        uint256 rentPerMonthUsdc;
        bool forSale;
        bool forRent;
        bool active;
        uint256 createdAt;
        string metadataUri;
    }

    struct PurchaseEscrow {
        uint256 escrowId;
        uint256 listingId;
        address buyer;
        address seller;
        uint256 amountUsdc;
        uint256 platformFeeUsdc;
        EscrowState state;
        uint256 createdAt;
        uint256 fundedAt;
        uint256 disputeDeadline;
    }

    struct RentAgreement {
        uint256 agreementId;
        uint256 listingId;
        address tenant;
        address landlord;
        uint256 rentPerMonthUsdc;
        uint256 depositUsdc;
        uint256 platformFeeUsdc;
        RentState state;
        uint256 startedAt;
        uint256 lastRentPaidAt;
        uint256 monthsPaid;
        bool depositReturned;
    }

    error ZeroAddress();
    error NotKycVerifier();
    error NotKyced();
    error UserIsBanned();
    error InvalidKycLevel();
    error ListingNotFound();
    error ListingNotActive();
    error NotListingOwner();
    error InvalidListingMode();
    error InvalidAmount();
    error SelfDealingNotAllowed();
    error EscrowNotFound();
    error InvalidEscrowState();
    error NotEscrowBuyer();
    error NotEscrowParty();
    error DisputeWindowExpired();
    error DisputeWindowNotExpired();
    error RentAgreementNotFound();
    error InvalidRentState();
    error NotRentTenant();
    error NotRentLandlord();
    error NotRentParty();
    error DepositAlreadyReturned();
    error InvalidReviewScore();
    error ReviewNotAllowed();
    error AlreadyReviewed();
    error NoFeesAvailable();
    error InvalidSignature();
    error SignatureExpired();
    error InvalidNonce();

    event FundsClaimable(address indexed recipient, uint256 amount);
    event FundsClaimed(address indexed recipient, uint256 amount);

    event ListingCreated(
        uint256 indexed listingId,
        address indexed owner,
        string title,
        string location,
        bool forSale,
        bool forRent
    );
    event ListingUpdated(
        uint256 indexed listingId,
        uint256 priceUsdc,
        uint256 rentPerMonthUsdc,
        bool forSale,
        bool forRent,
        bool active
    );

    event PurchaseInitiated(
        uint256 indexed escrowId,
        uint256 indexed listingId,
        address indexed buyer,
        address seller,
        uint256 amountUsdc
    );
    event EscrowFunded(uint256 indexed escrowId, address indexed buyer, uint256 totalPaidUsdc);
    event InspectionConfirmed(uint256 indexed escrowId, address indexed buyer);
    event PurchaseCompleted(uint256 indexed escrowId, address indexed buyer, address indexed seller, uint256 amountUsdc);
    event EscrowDisputed(uint256 indexed escrowId, address indexed raisedBy);
    event DisputeResolved(uint256 indexed escrowId, bool refundBuyer, uint256 amountUsdc);

    event RentInitiated(
        uint256 indexed agreementId,
        uint256 indexed listingId,
        address indexed tenant,
        address landlord,
        uint256 rentPerMonthUsdc,
        uint256 depositUsdc
    );
    event DepositPaid(uint256 indexed agreementId, address indexed tenant, uint256 depositUsdc);
    event RentActivated(uint256 indexed agreementId, uint256 startedAt);
    event RentPaid(uint256 indexed agreementId, uint256 month);
    event RentTerminated(uint256 indexed agreementId, address indexed terminatedBy);
    event DepositReturned(uint256 indexed agreementId, address indexed tenant, uint256 amountUsdc);
    event RentDisputeResolved(uint256 indexed agreementId, bool returnDepositToTenant);

    event ReviewLeft(address indexed reviewer, address indexed target, uint8 score);

    event UserVerified(address indexed user, uint8 level);
    event UserRevoked(address indexed user);
    event UserBanned(address indexed user);
    event KycVerifierUpdated(address indexed newKycVerifier);
    event KycSignerUpdated(address indexed newSigner);

    event FeesWithdrawn(address indexed to, uint256 amountUsdc);

    IERC20 public usdcToken;
    address public kycVerifier;

    uint256 public listingCount;
    uint256 public purchaseEscrowCount;
    uint256 public rentAgreementCount;
    uint256 public platformFeeBalance;

    mapping(address => UserProfile) public users;
    mapping(uint256 => Listing) public listings;
    mapping(uint256 => PurchaseEscrow) public purchaseEscrows;
    mapping(uint256 => RentAgreement) public rentAgreements;
    mapping(uint256 => mapping(address => bool)) public purchaseReviews;
    mapping(uint256 => mapping(address => bool)) public rentReviews;
    mapping(address => uint256) public claimable;
    address public kycSigner;
    mapping(address => uint256) public kycNonces;

    modifier onlyKyced() {
        UserProfile storage profile = users[msg.sender];
        if (profile.isBanned) revert UserIsBanned();
        if (!profile.isKyced) revert NotKyced();
        _;
    }

    modifier onlyKycVerifier() {
        if (msg.sender != kycVerifier) revert NotKycVerifier();
        _;
    }

    modifier onlyListingOwner(uint256 listingId) {
        Listing storage listing = listings[listingId];
        if (listing.owner == address(0)) revert ListingNotFound();
        if (listing.owner != msg.sender) revert NotListingOwner();
        _;
    }

    constructor(address _usdcToken, address _kycVerifier, address _kycSigner) Ownable(msg.sender) EIP712("PropChain", "1") {
        if (_usdcToken == address(0) || _kycVerifier == address(0)) revert ZeroAddress();
        usdcToken = IERC20(_usdcToken);
        kycVerifier = _kycVerifier;
        if (_kycSigner == address(0)) revert ZeroAddress();
        kycSigner = _kycSigner;
    }

    function setKycVerifier(address newVerifier) external onlyOwner {
        if (newVerifier == address(0)) revert ZeroAddress();
        kycVerifier = newVerifier;
        emit KycVerifierUpdated(newVerifier);
    }

    function setKycSigner(address newSigner) external onlyOwner {
        if (newSigner == address(0)) revert ZeroAddress();
        kycSigner = newSigner;
        emit KycSignerUpdated(newSigner);
    }

    function verifyWithSignature(
        address user,
        uint8 level,
        uint256 nonce,
        uint256 expiry,
        bytes calldata sig
    ) external {
        if (user == address(0)) revert ZeroAddress();
        if (level < 1 || level > 2) revert InvalidKycLevel();
        if (block.timestamp > expiry) revert SignatureExpired();
        if (nonce != kycNonces[user]) revert InvalidNonce();

        bytes32 structHash = keccak256(abi.encode(KYC_TYPEHASH, user, level, nonce, expiry));
        bytes32 digest = _hashTypedDataV4(structHash);
        address recovered = ECDSA.recover(digest, sig);
        if (recovered != kycSigner) revert InvalidSignature();

        unchecked {
            kycNonces[user]++;
        }

        _initializeUser(user);
        UserProfile storage profile = users[user];
        profile.isKyced = true;
        profile.kycLevel = level;

        emit UserVerified(user, level);
    }

    function verifyUser(address user, uint8 level) external onlyKycVerifier {
        if (user == address(0)) revert ZeroAddress();
        if (level < KYC_LEVEL_BASIC || level > KYC_LEVEL_FULL) revert InvalidKycLevel();

        _initializeUser(user);
        UserProfile storage profile = users[user];
        profile.isKyced = true;
        profile.kycLevel = level;

        emit UserVerified(user, level);
    }

    function revokeUser(address user) external onlyKycVerifier {
        if (user == address(0)) revert ZeroAddress();

        _initializeUser(user);
        UserProfile storage profile = users[user];
        profile.isKyced = false;
        profile.kycLevel = 0;

        emit UserRevoked(user);
    }

    function banUser(address user) external onlyOwner {
        if (user == address(0)) revert ZeroAddress();

        _initializeUser(user);
        users[user].isBanned = true;

        emit UserBanned(user);
    }

    function createListing(
        string calldata title,
        string calldata location,
        string calldata propertyType,
        uint256 priceUsdc,
        uint256 rentPerMonthUsdc,
        bool forSale,
        bool forRent,
        string calldata metadataUri
    ) external {
        if (!forSale && !forRent) revert InvalidListingMode();
        if (forSale && priceUsdc == 0) revert InvalidAmount();
        if (forRent && rentPerMonthUsdc == 0) revert InvalidAmount();

        unchecked {
            ++listingCount;
        }

        listings[listingCount] = Listing({
            listingId: listingCount,
            owner: msg.sender,
            title: title,
            location: location,
            propertyType: propertyType,
            priceUsdc: priceUsdc,
            rentPerMonthUsdc: rentPerMonthUsdc,
            forSale: forSale,
            forRent: forRent,
            active: true,
            createdAt: block.timestamp,
            metadataUri: metadataUri
        });

        emit ListingCreated(listingCount, msg.sender, title, location, forSale, forRent);
    }

    function updateListing(
        uint256 listingId,
        uint256 priceUsdc,
        uint256 rentPerMonthUsdc,
        bool forSale,
        bool forRent,
        bool active
    ) external onlyListingOwner(listingId) {
        if (!forSale && !forRent) revert InvalidListingMode();
        if (forSale && priceUsdc == 0) revert InvalidAmount();
        if (forRent && rentPerMonthUsdc == 0) revert InvalidAmount();

        Listing storage listing = listings[listingId];
        listing.priceUsdc = priceUsdc;
        listing.rentPerMonthUsdc = rentPerMonthUsdc;
        listing.forSale = forSale;
        listing.forRent = forRent;
        listing.active = active;

        emit ListingUpdated(listingId, priceUsdc, rentPerMonthUsdc, forSale, forRent, active);
    }

    function getListingCount() external view returns (uint256) {
        return listingCount;
    }

    function getListing(uint256 id) external view returns (Listing memory) {
        return listings[id];
    }

    function initiatePurchase(uint256 listingId) external onlyKyced {
        Listing storage listing = listings[listingId];
        if (listing.owner == address(0)) revert ListingNotFound();
        if (!listing.active || !listing.forSale) revert ListingNotActive();
        if (listing.priceUsdc == 0) revert InvalidAmount();
        if (msg.sender == listing.owner) revert SelfDealingNotAllowed();

        unchecked {
            ++purchaseEscrowCount;
        }

        uint256 fee = (listing.priceUsdc * PURCHASE_FEE_BPS) / BASIS_POINTS;
        purchaseEscrows[purchaseEscrowCount] = PurchaseEscrow({
            escrowId: purchaseEscrowCount,
            listingId: listingId,
            buyer: msg.sender,
            seller: listing.owner,
            amountUsdc: listing.priceUsdc,
            platformFeeUsdc: fee,
            state: EscrowState.PENDING,
            createdAt: block.timestamp,
            fundedAt: 0,
            disputeDeadline: 0
        });

        emit PurchaseInitiated(purchaseEscrowCount, listingId, msg.sender, listing.owner, listing.priceUsdc);
    }

    function fundPurchaseEscrow(uint256 escrowId) external nonReentrant {
        if (users[msg.sender].isBanned) revert UserIsBanned();

        PurchaseEscrow storage escrow = purchaseEscrows[escrowId];
        if (escrow.buyer == address(0)) revert EscrowNotFound();
        if (escrow.state != EscrowState.PENDING) revert InvalidEscrowState();
        if (msg.sender != escrow.buyer) revert NotEscrowBuyer();

        uint256 total = escrow.amountUsdc + escrow.platformFeeUsdc;
        if (total == 0) revert InvalidAmount();

        escrow.state = EscrowState.FUNDED;
        escrow.fundedAt = block.timestamp;
        escrow.disputeDeadline = block.timestamp + PURCHASE_DISPUTE_WINDOW;

        platformFeeBalance += escrow.platformFeeUsdc;

        usdcToken.safeTransferFrom(msg.sender, address(this), total);

        emit EscrowFunded(escrowId, msg.sender, total);
    }

    function confirmInspection(uint256 escrowId) external {
        PurchaseEscrow storage escrow = purchaseEscrows[escrowId];
        if (escrow.buyer == address(0)) revert EscrowNotFound();
        if (msg.sender != escrow.buyer) revert NotEscrowBuyer();
        if (escrow.state != EscrowState.FUNDED) revert InvalidEscrowState();

        escrow.state = EscrowState.INSPECTION;

        emit InspectionConfirmed(escrowId, msg.sender);
    }

    function completePurchase(uint256 escrowId) external nonReentrant {
        if (users[msg.sender].isBanned) revert UserIsBanned();

        PurchaseEscrow storage escrow = purchaseEscrows[escrowId];
        if (escrow.buyer == address(0)) revert EscrowNotFound();
        if (msg.sender != escrow.buyer) revert NotEscrowBuyer();
        if (escrow.state != EscrowState.INSPECTION) revert InvalidEscrowState();

        escrow.state = EscrowState.COMPLETED;
        listings[escrow.listingId].active = false;
        _incrementTransactionCount(escrow.buyer);
        _incrementTransactionCount(escrow.seller);

        claimable[escrow.seller] += escrow.amountUsdc;
        emit FundsClaimable(escrow.seller, escrow.amountUsdc);

        emit PurchaseCompleted(escrowId, escrow.buyer, escrow.seller, escrow.amountUsdc);
    }

    function disputePurchase(uint256 escrowId) external {
        PurchaseEscrow storage escrow = purchaseEscrows[escrowId];
        if (escrow.buyer == address(0)) revert EscrowNotFound();
        if (msg.sender != escrow.buyer && msg.sender != escrow.seller) revert NotEscrowParty();
        if (escrow.state != EscrowState.FUNDED && escrow.state != EscrowState.INSPECTION) revert InvalidEscrowState();
        if (block.timestamp > escrow.disputeDeadline) revert DisputeWindowExpired();

        escrow.state = EscrowState.DISPUTED;
        users[escrow.buyer].disputeCount += 1;
        users[escrow.seller].disputeCount += 1;

        emit EscrowDisputed(escrowId, msg.sender);
    }

    function resolveDispute(uint256 escrowId, bool refundBuyer) external onlyOwner nonReentrant {
        PurchaseEscrow storage escrow = purchaseEscrows[escrowId];
        if (escrow.buyer == address(0)) revert EscrowNotFound();
        if (escrow.state != EscrowState.DISPUTED) revert InvalidEscrowState();

        if (refundBuyer) {
            escrow.state = EscrowState.REFUNDED;
            uint256 refundAmount = escrow.amountUsdc + escrow.platformFeeUsdc;
            claimable[escrow.buyer] += refundAmount;
            platformFeeBalance -= escrow.platformFeeUsdc;
            emit FundsClaimable(escrow.buyer, refundAmount);
        } else {
            escrow.state = EscrowState.COMPLETED;
            listings[escrow.listingId].active = false;
            _incrementTransactionCount(escrow.buyer);
            _incrementTransactionCount(escrow.seller);
            claimable[escrow.seller] += escrow.amountUsdc;
            emit FundsClaimable(escrow.seller, escrow.amountUsdc);
        }

        emit DisputeResolved(escrowId, refundBuyer, escrow.amountUsdc);
    }

    function refundExpiredEscrow(uint256 escrowId) external nonReentrant {
        PurchaseEscrow storage escrow = purchaseEscrows[escrowId];
        if (escrow.buyer == address(0)) revert EscrowNotFound();
        if (escrow.state != EscrowState.FUNDED && escrow.state != EscrowState.INSPECTION) revert InvalidEscrowState();
        if (block.timestamp <= escrow.disputeDeadline) revert DisputeWindowNotExpired();

        escrow.state = EscrowState.REFUNDED;

        uint256 refundAmount = escrow.amountUsdc + escrow.platformFeeUsdc;
        claimable[escrow.buyer] += refundAmount;
        platformFeeBalance -= escrow.platformFeeUsdc;
        emit FundsClaimable(escrow.buyer, refundAmount);

        emit DisputeResolved(escrowId, true, escrow.amountUsdc);
    }

    function initiateRent(uint256 listingId) external onlyKyced {
        Listing storage listing = listings[listingId];
        if (listing.owner == address(0)) revert ListingNotFound();
        if (!listing.active || !listing.forRent) revert ListingNotActive();
        if (listing.rentPerMonthUsdc == 0) revert InvalidAmount();
        if (msg.sender == listing.owner) revert SelfDealingNotAllowed();

        unchecked {
            ++rentAgreementCount;
        }

        uint256 deposit = listing.rentPerMonthUsdc * 2;
        uint256 fee = (listing.rentPerMonthUsdc * RENT_FEE_BPS) / BASIS_POINTS;

        rentAgreements[rentAgreementCount] = RentAgreement({
            agreementId: rentAgreementCount,
            listingId: listingId,
            tenant: msg.sender,
            landlord: listing.owner,
            rentPerMonthUsdc: listing.rentPerMonthUsdc,
            depositUsdc: deposit,
            platformFeeUsdc: fee,
            state: RentState.PENDING,
            startedAt: 0,
            lastRentPaidAt: 0,
            monthsPaid: 0,
            depositReturned: false
        });

        emit RentInitiated(rentAgreementCount, listingId, msg.sender, listing.owner, listing.rentPerMonthUsdc, deposit);
    }

    function payDeposit(uint256 agreementId) external nonReentrant {
        if (users[msg.sender].isBanned) revert UserIsBanned();

        RentAgreement storage agreement = rentAgreements[agreementId];
        if (agreement.tenant == address(0)) revert RentAgreementNotFound();
        if (msg.sender != agreement.tenant) revert NotRentTenant();
        if (agreement.state != RentState.PENDING) revert InvalidRentState();
        if (agreement.depositUsdc == 0) revert InvalidAmount();

        agreement.state = RentState.DEPOSIT_PAID;

        usdcToken.safeTransferFrom(msg.sender, address(this), agreement.depositUsdc);

        emit DepositPaid(agreementId, msg.sender, agreement.depositUsdc);
    }

    function activateRent(uint256 agreementId) external {
        RentAgreement storage agreement = rentAgreements[agreementId];
        if (agreement.tenant == address(0)) revert RentAgreementNotFound();
        if (msg.sender != agreement.landlord) revert NotRentLandlord();
        if (agreement.state != RentState.DEPOSIT_PAID) revert InvalidRentState();

        agreement.state = RentState.ACTIVE;
        agreement.startedAt = block.timestamp;

        emit RentActivated(agreementId, block.timestamp);
    }

    function payRent(uint256 agreementId) external nonReentrant {
        if (users[msg.sender].isBanned) revert UserIsBanned();

        RentAgreement storage agreement = rentAgreements[agreementId];
        if (agreement.tenant == address(0)) revert RentAgreementNotFound();
        if (msg.sender != agreement.tenant) revert NotRentTenant();
        if (agreement.state != RentState.ACTIVE) revert InvalidRentState();

        uint256 rentAmount = agreement.rentPerMonthUsdc;
        uint256 fee = agreement.platformFeeUsdc;
        uint256 total = rentAmount + fee;
        if (rentAmount == 0 || total == 0) revert InvalidAmount();

        unchecked {
            agreement.monthsPaid += 1;
        }
        agreement.lastRentPaidAt = block.timestamp;

        platformFeeBalance += fee;
        _incrementTransactionCount(agreement.tenant);
        _incrementTransactionCount(agreement.landlord);

        usdcToken.safeTransferFrom(msg.sender, address(this), total);
        usdcToken.safeTransfer(agreement.landlord, rentAmount);

        emit RentPaid(agreementId, agreement.monthsPaid);
    }

    function terminateRent(uint256 agreementId) external nonReentrant {
        RentAgreement storage agreement = rentAgreements[agreementId];
        if (agreement.tenant == address(0)) revert RentAgreementNotFound();
        if (msg.sender != agreement.tenant && msg.sender != agreement.landlord) revert NotRentParty();
        if (agreement.state != RentState.DEPOSIT_PAID && agreement.state != RentState.ACTIVE) revert InvalidRentState();

        agreement.state = RentState.TERMINATED;

        if (!agreement.depositReturned && agreement.depositUsdc > 0) {
            agreement.depositReturned = true;

            uint256 tenantAmount = agreement.depositUsdc;
            uint256 landlordAmount;

            if (msg.sender == agreement.tenant && agreement.monthsPaid > 0) {
                landlordAmount = agreement.rentPerMonthUsdc;
                if (landlordAmount > tenantAmount) {
                    landlordAmount = tenantAmount;
                }
                tenantAmount = tenantAmount - landlordAmount;
            }

            if (tenantAmount > 0) {
                claimable[agreement.tenant] += tenantAmount;
                emit FundsClaimable(agreement.tenant, tenantAmount);
            }
            if (landlordAmount > 0) {
                claimable[agreement.landlord] += landlordAmount;
                emit FundsClaimable(agreement.landlord, landlordAmount);
            }

            emit DepositReturned(agreementId, agreement.tenant, tenantAmount);
        }

        emit RentTerminated(agreementId, msg.sender);
    }

    function returnDeposit(uint256 agreementId) external nonReentrant {
        RentAgreement storage agreement = rentAgreements[agreementId];
        if (agreement.tenant == address(0)) revert RentAgreementNotFound();
        if (msg.sender != agreement.landlord) revert NotRentLandlord();
        if (agreement.state != RentState.TERMINATED) revert InvalidRentState();
        if (agreement.depositReturned) revert DepositAlreadyReturned();
        if (agreement.depositUsdc == 0) revert InvalidAmount();

        agreement.depositReturned = true;

        claimable[agreement.tenant] += agreement.depositUsdc;
        emit FundsClaimable(agreement.tenant, agreement.depositUsdc);

        emit DepositReturned(agreementId, agreement.tenant, agreement.depositUsdc);
    }

    function disputeRent(uint256 agreementId) external {
        RentAgreement storage agreement = rentAgreements[agreementId];
        if (agreement.tenant == address(0)) revert RentAgreementNotFound();
        if (msg.sender != agreement.tenant && msg.sender != agreement.landlord) revert NotRentParty();
        if (
            agreement.state != RentState.DEPOSIT_PAID && agreement.state != RentState.ACTIVE
                && agreement.state != RentState.TERMINATED
        ) {
            revert InvalidRentState();
        }

        agreement.state = RentState.DISPUTED;
        users[agreement.tenant].disputeCount += 1;
        users[agreement.landlord].disputeCount += 1;
    }

    function resolveRentDispute(uint256 agreementId, bool returnDepositToTenant) external onlyOwner nonReentrant {
        RentAgreement storage agreement = rentAgreements[agreementId];
        if (agreement.tenant == address(0)) revert RentAgreementNotFound();
        if (agreement.state != RentState.DISPUTED) revert InvalidRentState();

        agreement.state = RentState.TERMINATED;

        if (!agreement.depositReturned && agreement.depositUsdc > 0) {
            agreement.depositReturned = true;
            address recipient = returnDepositToTenant ? agreement.tenant : agreement.landlord;
            claimable[recipient] += agreement.depositUsdc;
            emit FundsClaimable(recipient, agreement.depositUsdc);

            if (returnDepositToTenant) {
                emit DepositReturned(agreementId, agreement.tenant, agreement.depositUsdc);
            }
        }

        emit RentDisputeResolved(agreementId, returnDepositToTenant);
    }

    function leaveReview(
        address target,
        uint256 escrowOrAgreementId,
        bool isPurchase,
        uint8 score,
        string calldata
    ) external {
        if (target == address(0)) revert ZeroAddress();
        if (target == msg.sender) revert SelfDealingNotAllowed();
        if (score < MIN_REVIEW_SCORE || score > MAX_REVIEW_SCORE) revert InvalidReviewScore();

        if (isPurchase) {
            PurchaseEscrow storage escrow = purchaseEscrows[escrowOrAgreementId];
            if (escrow.buyer == address(0)) revert EscrowNotFound();
            if (escrow.state != EscrowState.COMPLETED) revert ReviewNotAllowed();
            if (msg.sender != escrow.buyer && msg.sender != escrow.seller) revert ReviewNotAllowed();
            address expectedTarget = msg.sender == escrow.buyer ? escrow.seller : escrow.buyer;
            if (target != expectedTarget) revert ReviewNotAllowed();
            if (purchaseReviews[escrowOrAgreementId][msg.sender]) revert AlreadyReviewed();

            purchaseReviews[escrowOrAgreementId][msg.sender] = true;
        } else {
            RentAgreement storage agreement = rentAgreements[escrowOrAgreementId];
            if (agreement.tenant == address(0)) revert RentAgreementNotFound();
            if (agreement.state != RentState.TERMINATED) revert ReviewNotAllowed();
            if (msg.sender != agreement.tenant && msg.sender != agreement.landlord) revert ReviewNotAllowed();
            address expectedTarget = msg.sender == agreement.tenant ? agreement.landlord : agreement.tenant;
            if (target != expectedTarget) revert ReviewNotAllowed();
            if (rentReviews[escrowOrAgreementId][msg.sender]) revert AlreadyReviewed();

            rentReviews[escrowOrAgreementId][msg.sender] = true;
        }

        _updateReputation(target, score);

        emit ReviewLeft(msg.sender, target, score);
    }

    function claimFunds() external nonReentrant {
        uint256 amount = claimable[msg.sender];
        if (amount == 0) revert InvalidAmount();

        claimable[msg.sender] = 0;
        usdcToken.safeTransfer(msg.sender, amount);

        emit FundsClaimed(msg.sender, amount);
    }

    function withdrawFees(address to) external onlyOwner nonReentrant {
        if (to == address(0)) revert ZeroAddress();

        uint256 amount = platformFeeBalance;
        if (amount == 0) revert NoFeesAvailable();

        platformFeeBalance = 0;
        usdcToken.safeTransfer(to, amount);

        emit FeesWithdrawn(to, amount);
    }

    function _initializeUser(address user) internal {
        UserProfile storage profile = users[user];
        if (profile.reputationScore == 0) {
            profile.reputationScore = 250;
        }
    }

    function _updateReputation(address target, uint8 score) internal {
        _initializeUser(target);
        UserProfile storage profile = users[target];

        uint256 mappedScore = uint256(score) * 100;
        uint256 count = profile.reviewCount;
        uint256 newScore = ((uint256(profile.reputationScore) * count) + mappedScore) / (count + 1);

        profile.reputationScore = uint16(newScore);
        profile.reviewCount = count + 1;
    }

    function _incrementTransactionCount(address user) internal {
        _initializeUser(user);
        unchecked {
            users[user].totalTransactions += 1;
        }
    }
}
