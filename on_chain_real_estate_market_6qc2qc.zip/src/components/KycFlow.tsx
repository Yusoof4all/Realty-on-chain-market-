import { useState, useRef, useCallback } from 'react'
import { useAccount } from 'wagmi'
import { Loader2, ShieldCheck, Upload, FileText, Image, X, CheckCircle2, AlertCircle, Clock } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'

type DocType = 'passport' | 'national_id' | 'drivers_license' | 'residence_permit'

const DOC_TYPES: { value: DocType; label: string; description: string }[] = [
  { value: 'passport',          label: 'Passport',          description: 'International travel document' },
  { value: 'national_id',       label: 'National ID',        description: 'Government-issued identity card' },
  { value: 'drivers_license',   label: "Driver's License",   description: 'State or national driving permit' },
  { value: 'residence_permit',  label: 'Residence Permit',   description: 'Official residency document' },
]

type FlowStep = 'select_doc' | 'upload' | 'submitting' | 'queued' | 'error'

function DropZone({ file, onFile, onClear }: { file: File | null; onFile: (f: File) => void; onClear: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setDragging(false)
    const f = e.dataTransfer.files[0]; if (f) onFile(f)
  }, [onFile])

  if (file) {
    const isImage = file.type.startsWith('image/')
    return (
      <div className="relative rounded-2xl border-2 overflow-hidden" style={{ borderColor: 'var(--success)', background: 'rgba(26,128,71,0.04)' }}>
        {isImage
          ? <img src={URL.createObjectURL(file)} alt="Document" className="w-full max-h-48 object-contain" />
          : (
            <div className="flex items-center gap-3 p-4">
              <div className="flex size-10 items-center justify-center rounded-xl" style={{ background: 'rgba(26,128,71,0.1)' }}>
                <FileText className="size-5" style={{ color: 'var(--success)' }} />
              </div>
              <div>
                <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{file.name}</div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{(file.size / 1024).toFixed(0)} KB · PDF</div>
              </div>
            </div>
          )
        }
        <button onClick={onClear} className="absolute top-2 right-2 flex size-6 items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.8)' }}>
          <X className="size-3.5" style={{ color: 'var(--ink-2)' }} />
        </button>
        <div className="px-3 py-1.5 text-xs font-medium" style={{ color: 'var(--success)', background: 'rgba(26,128,71,0.06)' }}>
          <CheckCircle2 className="inline size-3 mr-1" /> Document ready
        </div>
      </div>
    )
  }

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      className="cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all"
      style={{ borderColor: dragging ? 'var(--accent)' : 'var(--border)', background: dragging ? 'rgba(18,45,69,0.03)' : 'var(--surface-muted)' }}
    >
      <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp,application/pdf" className="sr-only"
        onChange={e => { const f = e.target.files?.[0]; if (f) onFile(f) }} />
      <div className="flex flex-col items-center gap-3">
        <div className="flex size-12 items-center justify-center rounded-2xl" style={{ background: 'rgba(18,45,69,0.06)' }}>
          <Upload className="size-5" style={{ color: 'var(--accent)' }} />
        </div>
        <div>
          <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Drop your document here</div>
          <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>or click to browse · JPEG, PNG, WebP, PDF · max 20 MB</div>
        </div>
        <div className="flex gap-2">
          {[['image/jpeg', 'JPG'], ['image/png', 'PNG'], ['application/pdf', 'PDF']].map(([t, lbl]) => (
            <span key={t} className="flex items-center gap-1 rounded-lg px-2 py-0.5 text-xs font-medium" style={{ background: 'var(--border)', color: 'var(--muted)' }}>
              {t.startsWith('image') ? <Image className="size-2.5" /> : <FileText className="size-2.5" />} {lbl}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function KycFlow({ onComplete }: { onComplete?: () => void }) {
  const { address } = useAccount()
  const [step, setStep] = useState<FlowStep>('select_doc')
  const [docType, setDocType] = useState<DocType | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [errorMsg, setErrorMsg] = useState('')

  const handleSubmitDoc = async () => {
    if (!file || !docType || !address) return
    setStep('submitting')
    setErrorMsg('')

    const formData = new FormData()
    formData.append('wallet', address)
    formData.append('docType', docType)
    formData.append('document', file)

    try {
      const res = await fetch('/api/kyc/submit', { method: 'POST', body: formData })
      const data = await res.json() as { ok?: boolean; error?: string; status?: string; message?: string }

      if (!res.ok || !data.ok) {
        setErrorMsg(data.error ?? 'Submission failed. Please try again.')
        setStep('error'); return
      }

      if (data.status === 'already_approved') {
        toast.success('Your wallet is already KYC-verified!')
        onComplete?.(); return
      }

      setStep('queued')
      toast.success('Document submitted for review!')
    } catch {
      setErrorMsg('Network error — is the KYC server running? Try refreshing.')
      setStep('error')
    }
  }

  return (
    <div className="rounded-2xl overflow-hidden border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
      {/* Header */}
      <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center gap-2.5">
          <div className="flex size-8 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
            <ShieldCheck className="size-4" style={{ color: 'var(--accent)' }} />
          </div>
          <div>
            <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Identity Verification</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>Upload a government ID to request KYC — an admin approves on-chain</div>
          </div>
        </div>
      </div>

      <div className="p-5">
        <AnimatePresence mode="wait">

          {/* Step 1 — Select document type */}
          {step === 'select_doc' && (
            <motion.div key="select" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="space-y-3">
              <p className="text-sm" style={{ color: 'var(--ink-2)' }}>What type of document will you upload?</p>
              <div className="grid grid-cols-2 gap-2">
                {DOC_TYPES.map(dt => (
                  <button key={dt.value} onClick={() => setDocType(dt.value)}
                    className="text-left rounded-xl p-3 border-2 transition-all"
                    style={{ borderColor: docType === dt.value ? 'var(--accent)' : 'var(--border)', background: docType === dt.value ? 'rgba(18,45,69,0.04)' : 'var(--surface-muted)' }}>
                    <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{dt.label}</div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{dt.description}</div>
                  </button>
                ))}
              </div>
              <button disabled={!docType} onClick={() => setStep('upload')}
                className="mt-1 w-full rounded-2xl py-3 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ background: 'var(--accent)' }}>
                Continue
              </button>
            </motion.div>
          )}

          {/* Step 2 — Upload */}
          {step === 'upload' && (
            <motion.div key="upload" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="space-y-4">
              <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
                Upload a clear photo of your <strong>{DOC_TYPES.find(d => d.value === docType)?.label}</strong>.
              </p>
              <DropZone file={file} onFile={setFile} onClear={() => setFile(null)} />
              <div className="rounded-xl px-3 py-2.5 text-xs" style={{ background: 'rgba(18,45,69,0.04)', color: 'var(--muted)' }}>
                Your document is validated for format only. No document data is stored. An admin will review and approve your wallet on-chain.
              </div>
              <div className="flex gap-2">
                <button onClick={() => setStep('select_doc')} className="rounded-2xl px-4 py-3 text-sm font-medium" style={{ color: 'var(--ink-2)' }}>Back</button>
                <button disabled={!file} onClick={() => { void handleSubmitDoc() }}
                  className="flex-1 flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{ background: 'var(--accent)' }}>
                  <ShieldCheck className="size-4" /> Submit for Review
                </button>
              </div>
            </motion.div>
          )}

          {/* Submitting */}
          {step === 'submitting' && (
            <motion.div key="submitting" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
              className="py-8 flex flex-col items-center gap-4 text-center">
              <div className="flex size-14 items-center justify-center rounded-2xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
                <Loader2 className="size-7 animate-spin" style={{ color: 'var(--accent)' }} />
              </div>
              <div>
                <div className="font-semibold" style={{ color: 'var(--ink)' }}>Uploading document…</div>
                <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Validating file format</div>
              </div>
            </motion.div>
          )}

          {/* Queued — waiting for admin */}
          {step === 'queued' && (
            <motion.div key="queued" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="py-6 flex flex-col items-center gap-3 text-center">
              <div className="flex size-14 items-center justify-center rounded-2xl" style={{ background: 'rgba(251,191,36,0.1)' }}>
                <Clock className="size-8" style={{ color: '#d97706' }} />
              </div>
              <div>
                <div className="font-bold text-base" style={{ color: 'var(--ink)' }}>Under Review</div>
                <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
                  Your document has been submitted. An admin will verify your identity and approve your wallet on-chain. Come back to check your KYC status.
                </div>
              </div>
              <button onClick={() => { setStep('select_doc'); setFile(null); setDocType(null) }}
                className="mt-2 text-sm underline" style={{ color: 'var(--accent-hover)' }}>
                Submit a different document
              </button>
            </motion.div>
          )}

          {/* Error */}
          {step === 'error' && (
            <motion.div key="error" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
              <div className="flex items-start gap-3 rounded-xl p-3.5" style={{ background: 'rgba(186,43,76,0.06)', border: '1px solid rgba(186,43,76,0.15)' }}>
                <AlertCircle className="size-5 shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
                <div>
                  <div className="text-sm font-semibold" style={{ color: 'var(--danger)' }}>Submission failed</div>
                  <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{errorMsg}</div>
                </div>
              </div>
              <button onClick={() => { setStep('upload'); setFile(null); setErrorMsg('') }}
                className="w-full rounded-2xl py-3 text-sm font-semibold text-white" style={{ background: 'var(--accent)' }}>
                Try Again
              </button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  )
}
