/**
 * KYC Admin Panel — visible only when connected as the kycVerifier (deployer wallet).
 * Shows all pending KYC requests and lets you approve (level 1 or 2) or reject them
 * by calling verifyUser / revokeUser on-chain.
 *
 * Users who need KYC click "Request KYC" in their Profile — this posts their wallet
 * address to the backend KYC queue. The admin sees the queue here and approves with
 * a single wallet click.
 */

import { useState, useCallback, useEffect } from 'react'
import { useAccount, useWriteContract, useSwitchChain } from 'wagmi'
import { Loader2, ShieldCheck, ShieldX, RefreshCw, UserCheck, Clock, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import { REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl } from '@/hooks/useRealEstateContract'

// kycVerifier == platform deployer wallet
export const KYC_VERIFIER = '0x5b12ce46c7194ad57d143bc22847224047b1ef42'

interface KycRequest {
  wallet: string
  docType: string
  submittedAt: number
  status: 'pending' | 'approved' | 'rejected'
  txHash?: string
}

// ─── ABI additions for admin functions ──────────────────────────────────────
const ADMIN_ABI = [
  { name: 'verifyUser', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'user', type: 'address' }, { name: 'level', type: 'uint8' }], outputs: [] },
  { name: 'revokeUser', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'user', type: 'address' }], outputs: [] },
  { name: 'kycVerifier', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
] as const

function RequestCard({
  req,
  onApprove,
  onReject,
  busy,
}: {
  req: KycRequest
  onApprove: (wallet: string, level: 1 | 2) => Promise<void>
  onReject: (wallet: string) => Promise<void>
  busy: boolean
}) {
  const short = `${req.wallet.slice(0, 8)}…${req.wallet.slice(-6)}`
  const date = new Date(req.submittedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })
  const DOC_LABELS: Record<string, string> = {
    passport: 'Passport',
    national_id: 'National ID',
    drivers_license: "Driver's License",
    residence_permit: 'Residence Permit',
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      className="rounded-2xl p-4 border"
      style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="flex size-9 items-center justify-center rounded-xl shrink-0" style={{ background: 'rgba(18,45,69,0.07)' }}>
            <UserCheck className="size-4" style={{ color: 'var(--ink-2)' }} />
          </div>
          <div>
            <div className="font-semibold text-sm mono" style={{ color: 'var(--ink)' }}>{short}</div>
            <div className="text-xs mt-0.5 flex items-center gap-1.5" style={{ color: 'var(--muted)' }}>
              <Clock className="size-3" /> {date}
            </div>
          </div>
        </div>

        {req.status === 'pending' && (
          <span className="px-2 py-0.5 rounded-full text-xs font-medium" style={{ background: 'rgba(251,191,36,0.12)', color: '#d97706' }}>Pending</span>
        )}
        {req.status === 'approved' && (
          <span className="px-2 py-0.5 rounded-full text-xs font-medium flex items-center gap-1" style={{ background: 'rgba(26,128,71,0.1)', color: 'var(--success)' }}>
            <CheckCircle2 className="size-3" /> Approved
          </span>
        )}
        {req.status === 'rejected' && (
          <span className="px-2 py-0.5 rounded-full text-xs font-medium flex items-center gap-1" style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--danger)' }}>
            <XCircle className="size-3" /> Rejected
          </span>
        )}
      </div>

      <div className="flex flex-wrap gap-2 mb-3">
        <span className="px-2.5 py-1 rounded-lg text-xs font-medium" style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}>
          {DOC_LABELS[req.docType] ?? req.docType}
        </span>
        <span className="px-2.5 py-1 rounded-lg text-xs font-medium mono" style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>
          {req.wallet.toLowerCase()}
        </span>
      </div>

      {req.txHash && (
        <a href={getTxUrl(req.txHash)} target="_blank" rel="noopener noreferrer" className="text-xs underline block mb-2" style={{ color: 'var(--accent-hover)' }}>
          View tx
        </a>
      )}

      {req.status === 'pending' && (
        <div className="flex gap-2">
          <button
            disabled={busy}
            onClick={() => { void onApprove(req.wallet, 2) }}
            className="flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-semibold text-white transition-all hover:scale-[1.02] disabled:opacity-40"
            style={{ background: 'var(--success)' }}
          >
            <ShieldCheck className="size-3.5" /> Full KYC (L2)
          </button>
          <button
            disabled={busy}
            onClick={() => { void onApprove(req.wallet, 1) }}
            className="flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-semibold transition-all hover:scale-[1.02] disabled:opacity-40"
            style={{ background: 'rgba(18,45,69,0.08)', color: 'var(--ink-2)' }}
          >
            <ShieldCheck className="size-3.5" /> Basic KYC (L1)
          </button>
          <button
            disabled={busy}
            onClick={() => { void onReject(req.wallet) }}
            className="flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition-all hover:scale-[1.02] disabled:opacity-40"
            style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--danger)' }}
          >
            <ShieldX className="size-3.5" />
          </button>
        </div>
      )}
    </motion.div>
  )
}

export default function AdminView() {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { writeContractAsync, isPending } = useWriteContract()
  const wrongChain = chainId !== CHAIN_ID

  const [requests, setRequests] = useState<KycRequest[]>([])
  const [loading, setLoading] = useState(false)
  const [txPending, setTxPending] = useState(false)

  const isAdmin = address?.toLowerCase() === KYC_VERIFIER

  const fetchRequests = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/kyc/requests')
      if (res.ok) {
        const data = await res.json() as { requests: KycRequest[] }
        setRequests(data.requests ?? [])
      }
    } catch {
      toast.error('Could not load KYC queue')
    } finally {
      setLoading(false)
    }
  }, [])

  // Initial load when admin wallet connects
  useEffect(() => {
    if (isAdmin) { void fetchRequests() }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin])

  const resolveRequest = async (wallet: string, action: 'approve' | 'reject', txHash: string) => {
    setRequests(prev =>
      prev.map(r => r.wallet.toLowerCase() === wallet.toLowerCase()
        ? { ...r, status: action === 'approve' ? 'approved' : 'rejected', txHash }
        : r),
    )
    await fetch('/api/kyc/resolve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wallet, status: action === 'approve' ? 'approved' : 'rejected', txHash }),
    })
    toast.success(action === 'approve' ? 'KYC approved on-chain!' : 'KYC rejected on-chain')
  }

  const handleApprove = async (wallet: string, level: 1 | 2) => {
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    setTxPending(true)
    try {
      const hash = await writeContractAsync({
        address: REAL_ESTATE_ADDRESS,
        abi: [...REAL_ESTATE_ABI, ...ADMIN_ABI],
        functionName: 'verifyUser',
        args: [wallet as `0x${string}`, level],
        chainId: CHAIN_ID,
      })
      await resolveRequest(wallet, 'approve', hash)
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      toast.error('Transaction failed: ' + msg.slice(0, 80))
    } finally {
      setTxPending(false)
    }
  }

  const handleReject = async (wallet: string) => {
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    setTxPending(true)
    try {
      const hash = await writeContractAsync({
        address: REAL_ESTATE_ADDRESS,
        abi: [...REAL_ESTATE_ABI, ...ADMIN_ABI],
        functionName: 'revokeUser',
        args: [wallet as `0x${string}`],
        chainId: CHAIN_ID,
      })
      await resolveRequest(wallet, 'reject', hash)
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      toast.error('Transaction failed: ' + msg.slice(0, 80))
    } finally {
      setTxPending(false)
    }
  }

  const busy = isPending || txPending

  const pending = requests.filter(r => r.status === 'pending')
  const resolved = requests.filter(r => r.status !== 'pending')

  if (!address) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <p style={{ color: 'var(--muted)' }}>Connect the admin wallet to access this panel.</p>
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center flex flex-col items-center gap-3">
        <AlertTriangle className="size-8" style={{ color: 'var(--danger)' }} />
        <p className="font-semibold" style={{ color: 'var(--ink)' }}>Access denied</p>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>This panel requires the KYC Verifier wallet.</p>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="display text-2xl font-bold tracking-tight" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>KYC Admin</h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--muted)' }}>Review and approve identity verification requests</p>
        </div>
        <button
          onClick={() => { void fetchRequests() }}
          disabled={loading}
          className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium transition-colors"
          style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}
        >
          <RefreshCw className={`size-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: 'Pending', value: pending.length, color: '#d97706' },
          { label: 'Approved', value: resolved.filter(r => r.status === 'approved').length, color: 'var(--success)' },
          { label: 'Rejected', value: resolved.filter(r => r.status === 'rejected').length, color: 'var(--danger)' },
        ].map(s => (
          <div key={s.label} className="rounded-2xl p-3 text-center" style={{ background: 'var(--surface-muted)' }}>
            <div className="display text-2xl font-bold tabular-nums" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Pending queue */}
      <div className="mb-2">
        <h2 className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: 'var(--muted)' }}>
          Pending Requests {pending.length > 0 && <span className="ml-1 px-1.5 py-0.5 rounded-full" style={{ background: 'rgba(251,191,36,0.15)', color: '#d97706' }}>{pending.length}</span>}
        </h2>
        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="size-6 animate-spin" style={{ color: 'var(--muted)' }} /></div>
        ) : pending.length === 0 ? (
          <div className="rounded-2xl p-8 text-center border border-dashed" style={{ borderColor: 'var(--border)' }}>
            <ShieldCheck className="size-7 mx-auto mb-2" style={{ color: 'var(--muted)' }} />
            <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>No pending requests</p>
            <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>When users submit KYC documents, they appear here.</p>
          </div>
        ) : (
          <AnimatePresence>
            <div className="space-y-3">
              {pending.map(req => (
                <RequestCard key={req.wallet} req={req} onApprove={handleApprove} onReject={handleReject} busy={busy} />
              ))}
            </div>
          </AnimatePresence>
        )}
      </div>

      {/* Recent resolved */}
      {resolved.length > 0 && (
        <div className="mt-6">
          <h2 className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: 'var(--muted)' }}>Recently Resolved</h2>
          <div className="space-y-3">
            {resolved.slice(0, 10).map(req => (
              <RequestCard key={req.wallet} req={req} onApprove={handleApprove} onReject={handleReject} busy={busy} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
