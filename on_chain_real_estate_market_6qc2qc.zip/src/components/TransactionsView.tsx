import { useState } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { erc20Abi } from 'viem'
import { Loader2, ShieldAlert, ArrowDownToLine, FileCheck, CheckCircle2, AlertTriangle, Key, DollarSign } from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import { toast } from 'sonner'
import {
  REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl,
  formatUsdc, parseUsdc,
  useClaimable, useUsdcAllowance
} from '@/hooks/useRealEstateContract'
import { getUsdc } from '@/onchain-facts'

type Tab = 'purchase' | 'rent'
type EscrowFn = 'fundPurchaseEscrow' | 'confirmInspection' | 'completePurchase' | 'disputePurchase'
type RentFn = 'payDeposit' | 'activateRent' | 'payRent' | 'terminateRent'

interface NumberInputProps {
  value: string
  onChange: (v: string) => void
  placeholder: string
  label: string
}

function NumberInput({ value, onChange, placeholder, label }: NumberInputProps) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-widest mb-1 block" style={{ color: 'var(--muted)' }}>{label}</label>
      <input
        inputMode="numeric"
        value={value}
        onChange={e => onChange(e.target.value.replace(/[^0-9.]/g, ''))}
        placeholder={placeholder}
        className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
        style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
      />
    </div>
  )
}

interface EscrowActionsProps {
  escrowId: string
}

function EscrowActions({ escrowId }: EscrowActionsProps) {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { data: allowance } = useUsdcAllowance(address)
  const { writeContract, data: hash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })
  const wrongChain = chainId !== CHAIN_ID
  const usdcFact = getUsdc(CHAIN_ID)

  const [escrowAmount, setEscrowAmount] = useState('')
  const [activeAction, setActiveAction] = useState<EscrowFn | null>(null)

  const callAction = (fn: EscrowFn) => {
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    setActiveAction(fn)
    const id = BigInt(escrowId)
    if (fn === 'fundPurchaseEscrow') {
      const amountBigInt = parseUsdc(escrowAmount || '0')
      if ((allowance ?? 0n) < amountBigInt) {
        writeContract({
          address: usdcFact?.address as `0x${string}`,
          abi: erc20Abi,
          functionName: 'approve',
          args: [REAL_ESTATE_ADDRESS, amountBigInt],
          chainId: CHAIN_ID,
        })
        toast.info('Approving USDC first, then fund again')
        return
      }
    }
    writeContract({
      address: REAL_ESTATE_ADDRESS,
      abi: REAL_ESTATE_ABI,
      functionName: fn,
      args: [id],
      chainId: CHAIN_ID,
    })
  }

  const busy = isPending || isConfirming

  const actions: { fn: EscrowFn; label: string; icon: React.ReactNode; color: string; description: string }[] = [
    { fn: 'fundPurchaseEscrow', label: 'Fund Escrow', icon: <DollarSign className="size-3.5" />, color: 'var(--accent)', description: 'Send USDC to escrow' },
    { fn: 'confirmInspection', label: 'Confirm Inspection', icon: <FileCheck className="size-3.5" />, color: '#1061a6', description: 'Mark property inspected' },
    { fn: 'completePurchase', label: 'Complete Purchase', icon: <CheckCircle2 className="size-3.5" />, color: 'var(--success)', description: 'Release funds to seller' },
    { fn: 'disputePurchase', label: 'Raise Dispute', icon: <AlertTriangle className="size-3.5" />, color: 'var(--danger)', description: 'Flag issue for resolution' },
  ]

  return (
    <div className="space-y-3">
      {actions.map(a => (
        <div key={a.fn}>
          {a.fn === 'fundPurchaseEscrow' && (
            <div className="mb-2">
              <NumberInput value={escrowAmount} onChange={setEscrowAmount} placeholder="Amount + fee" label="Total USDC Amount" />
            </div>
          )}
          <button
            disabled={busy || !address}
            onClick={() => callAction(a.fn)}
            className="w-full flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium transition-all hover:opacity-90 disabled:opacity-40"
            style={{ background: `${a.color}15`, color: a.color, border: `1px solid ${a.color}30` }}
          >
            {busy && activeAction === a.fn ? <Loader2 className="size-3.5 animate-spin" /> : a.icon}
            <span>{a.label}</span>
            <span className="ml-auto text-xs opacity-60">{a.description}</span>
          </button>
        </div>
      ))}
      {isSuccess && hash && (
        <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="block text-center text-xs underline mt-2" style={{ color: 'var(--accent-hover)' }}>
          View transaction
        </a>
      )}
    </div>
  )
}

interface RentActionsProps {
  agreementId: string
}

function RentActions({ agreementId }: RentActionsProps) {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { data: allowance } = useUsdcAllowance(address)
  const { writeContract, data: hash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })
  const wrongChain = chainId !== CHAIN_ID
  const usdcFact = getUsdc(CHAIN_ID)
  const [depositAmount, setDepositAmount] = useState('')
  const [rentAmount, setRentAmount] = useState('')
  const [activeAction, setActiveAction] = useState<RentFn | null>(null)

  const busy = isPending || isConfirming

  const callAction = (fn: RentFn, amount?: string) => {
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    const id = BigInt(agreementId)
    setActiveAction(fn)

    if ((fn === 'payDeposit' || fn === 'payRent') && amount) {
      const amtBigInt = parseUsdc(amount)
      if ((allowance ?? 0n) < amtBigInt) {
        writeContract({
          address: usdcFact?.address as `0x${string}`,
          abi: erc20Abi,
          functionName: 'approve',
          args: [REAL_ESTATE_ADDRESS, amtBigInt],
          chainId: CHAIN_ID,
        })
        toast.info('Approving USDC first, then retry')
        return
      }
    }

    writeContract({
      address: REAL_ESTATE_ADDRESS,
      abi: REAL_ESTATE_ABI,
      functionName: fn,
      args: [id],
      chainId: CHAIN_ID,
    })
  }

  const actions: { fn: RentFn; label: string; amount?: string; setAmount?: (v: string) => void; icon: React.ReactNode; color: string }[] = [
    { fn: 'payDeposit', label: 'Pay Deposit', amount: depositAmount, setAmount: setDepositAmount, icon: <ArrowDownToLine className="size-3.5" />, color: '#1061a6' },
    { fn: 'activateRent', label: 'Activate Rent', icon: <Key className="size-3.5" />, color: 'var(--success)' },
    { fn: 'payRent', label: 'Pay Rent', amount: rentAmount, setAmount: setRentAmount, icon: <DollarSign className="size-3.5" />, color: 'var(--accent)' },
    { fn: 'terminateRent', label: 'Terminate', icon: <AlertTriangle className="size-3.5" />, color: 'var(--danger)' },
  ]

  return (
    <div className="space-y-2">
      {actions.map(a => (
        <div key={a.fn}>
          {a.setAmount !== undefined && a.amount !== undefined && (
            <div className="mb-1">
              <NumberInput value={a.amount} onChange={a.setAmount} placeholder="0.00" label={a.fn === 'payDeposit' ? 'Deposit USDC' : 'Rent + Fee USDC'} />
            </div>
          )}
          <button
            disabled={busy || !address}
            onClick={() => callAction(a.fn, a.amount)}
            className="w-full flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium transition-all hover:opacity-90 disabled:opacity-40"
            style={{ background: `${a.color}15`, color: a.color, border: `1px solid ${a.color}30` }}
          >
            {busy && activeAction === a.fn ? <Loader2 className="size-3.5 animate-spin" /> : a.icon}
            {a.label}
          </button>
        </div>
      ))}
      {isSuccess && hash && (
        <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="block text-center text-xs underline mt-2" style={{ color: 'var(--accent-hover)' }}>
          View transaction
        </a>
      )}
    </div>
  )
}

function ClaimFunds() {
  const { address } = useAccount()
  const { data: claimableRaw } = useClaimable(address)
  const { writeContract, data: hash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })

  const amount = claimableRaw ?? 0n
  if (amount === 0n) return null

  const handleClaim = () => {
    writeContract({
      address: REAL_ESTATE_ADDRESS,
      abi: REAL_ESTATE_ABI,
      functionName: 'claimFunds',
      args: [],
      chainId: CHAIN_ID,
    })
  }

  return (
    <div className="mb-6 rounded-2xl p-4 border" style={{ background: 'rgba(26,128,71,0.06)', borderColor: 'rgba(26,128,71,0.2)' }}>
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="text-sm font-semibold" style={{ color: 'var(--success)' }}>Funds Available to Claim</div>
          <div className="display text-2xl font-bold tabular-nums mt-0.5" style={{ color: 'var(--ink)' }}>
            {formatUsdc(amount)} <span className="text-base font-medium" style={{ color: 'var(--muted)' }}>USDC</span>
          </div>
        </div>
        <button
          disabled={isPending || isConfirming}
          onClick={handleClaim}
          className="shrink-0 rounded-xl px-4 py-2.5 text-sm font-semibold text-white transition-all hover:scale-[1.02] disabled:opacity-40"
          style={{ background: 'var(--success)' }}
        >
          {isPending || isConfirming ? <Loader2 className="size-4 animate-spin" /> : 'Claim'}
        </button>
      </div>
      {isSuccess && hash && (
        <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="text-xs underline mt-2 block" style={{ color: 'var(--success)' }}>View transaction</a>
      )}
    </div>
  )
}

export default function TransactionsView() {
  const { address } = useAccount()
  const [tab, setTab] = useState<Tab>('purchase')
  const [escrowId, setEscrowId] = useState('')
  const [agreementId, setAgreementId] = useState('')

  if (!address) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 flex flex-col items-center gap-4 text-center">
        <ShieldAlert className="size-8" style={{ color: 'var(--muted)' }} />
        <p className="font-medium" style={{ color: 'var(--ink)' }}>Connect your wallet to manage deals</p>
        <ConnectKitButton />
      </div>
    )
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="display text-2xl font-bold tracking-tight" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>My Deals</h1>
        <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Manage active escrows and rent agreements.</p>
      </div>

      <ClaimFunds />

      <div className="flex gap-1 rounded-xl p-1 mb-6" style={{ background: 'var(--surface-muted)' }}>
        {(['purchase', 'rent'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="flex-1 rounded-lg py-2 text-sm font-medium transition-all"
            style={{
              background: tab === t ? 'white' : 'transparent',
              color: tab === t ? 'var(--ink)' : 'var(--muted)',
              boxShadow: tab === t ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
            }}
          >
            {t === 'purchase' ? 'Purchase Escrow' : 'Rent Agreement'}
          </button>
        ))}
      </div>

      {tab === 'purchase' ? (
        <div className="rounded-2xl overflow-hidden border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
          <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border)' }}>
            <h3 className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Purchase Escrow Actions</h3>
            <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>Enter your escrow ID from My Deals after initiating a purchase</p>
          </div>
          <div className="p-4 space-y-4">
            <NumberInput value={escrowId} onChange={setEscrowId} placeholder="1" label="Escrow ID" />
            {escrowId && <EscrowActions escrowId={escrowId} />}
          </div>
        </div>
      ) : (
        <div className="rounded-2xl overflow-hidden border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
          <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border)' }}>
            <h3 className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Rent Agreement Actions</h3>
            <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>Enter your agreement ID after initiating a rental</p>
          </div>
          <div className="p-4 space-y-4">
            <NumberInput value={agreementId} onChange={setAgreementId} placeholder="1" label="Agreement ID" />
            {agreementId && <RentActions agreementId={agreementId} />}
          </div>
        </div>
      )}

      <div className="mt-6 rounded-2xl p-4 space-y-2" style={{ background: 'var(--surface-muted)' }}>
        <div className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--muted)' }}>How It Works</div>
        {tab === 'purchase' ? (
          <ol className="space-y-1.5 list-decimal list-inside">
            {['Initiate purchase from Discover', 'Fund escrow (approve USDC first)', 'Confirm inspection on-site', 'Complete purchase → funds release to seller', 'Raise dispute within 30 days if issues'].map(s => (
              <li key={s} className="text-xs" style={{ color: 'var(--ink-2)' }}>{s}</li>
            ))}
          </ol>
        ) : (
          <ol className="space-y-1.5 list-decimal list-inside">
            {['Initiate rental from Discover', 'Pay 2-month deposit (approve USDC)', 'Landlord activates agreement', 'Pay rent monthly (+ 0.5% fee)', 'Terminate and claim deposit refund'].map(s => (
              <li key={s} className="text-xs" style={{ color: 'var(--ink-2)' }}>{s}</li>
            ))}
          </ol>
        )}
      </div>
    </div>
  )
}
