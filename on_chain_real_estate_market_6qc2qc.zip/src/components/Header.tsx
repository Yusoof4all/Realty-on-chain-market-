import { ConnectKitButton } from 'connectkit'
import { Building2, Moon, Sun, ShieldCheck } from 'lucide-react'
import { useTheme } from '@/ThemeContext'
import { useAccount } from 'wagmi'
import { KYC_VERIFIER } from './AdminView'

interface HeaderProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

const TABS = [
  { id: 'discover', label: 'Discover' },
  { id: 'list', label: 'List Property' },
  { id: 'transactions', label: 'My Deals' },
  { id: 'profile', label: 'My Profile' },
]

export default function Header({ activeTab, onTabChange }: HeaderProps) {
  const { theme, toggle } = useTheme()
  const { address } = useAccount()
  const isAdmin = address?.toLowerCase() === KYC_VERIFIER

  const tabs = isAdmin ? [...TABS, { id: 'admin', label: 'KYC Admin' }] : TABS

  return (
    <header className="sticky top-0 z-40 border-b backdrop-blur-xl" style={{ background: 'var(--header-bg)', borderColor: 'var(--border)' }}>
      <div className="mx-auto max-w-6xl px-4">
        <div className="flex h-14 items-center justify-between gap-4">
          {/* Logo */}
          <button onClick={() => onTabChange('discover')} className="flex items-center gap-2.5 shrink-0">
            <div className="flex size-8 items-center justify-center rounded-xl" style={{ background: 'var(--accent)' }}>
              <Building2 className="size-4 text-white" />
            </div>
            <span className="display text-base font-bold tracking-tight hidden sm:block" style={{ color: 'var(--ink)' }}>
              PropChain
            </span>
          </button>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-0.5 rounded-xl p-0.5" style={{ background: 'var(--surface-muted)' }}>
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition-all"
                style={{
                  background: activeTab === tab.id ? 'var(--surface-strong)' : 'transparent',
                  color: activeTab === tab.id ? 'var(--ink)' : 'var(--muted)',
                  boxShadow: activeTab === tab.id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                }}
              >
                {tab.id === 'admin' && <ShieldCheck className="size-3.5" style={{ color: activeTab === 'admin' ? 'var(--success)' : 'var(--muted)' }} />}
                {tab.label}
              </button>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {/* Dark/light toggle */}
            <button
              onClick={toggle}
              aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
              className="flex size-8 items-center justify-center rounded-xl transition-colors"
              style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}
            >
              {theme === 'dark'
                ? <Sun className="size-4" />
                : <Moon className="size-4" />
              }
            </button>
            <ConnectKitButton />
          </div>
        </div>

        {/* Mobile nav */}
        <div className="flex md:hidden items-center gap-1 pb-2 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="shrink-0 flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-medium transition-all"
              style={{
                background: activeTab === tab.id ? 'var(--accent)' : 'var(--surface-muted)',
                color: activeTab === tab.id ? 'white' : 'var(--muted)',
              }}
            >
              {tab.id === 'admin' && <ShieldCheck className="size-3" />}
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  )
}
