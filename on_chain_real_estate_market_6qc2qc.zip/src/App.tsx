import { useState } from 'react'
import { ThemeProvider } from '@/ThemeContext'
import Header from '@/components/Header'
import DiscoverView from '@/components/DiscoverView'
import ListPropertyView from '@/components/ListPropertyView'
import TransactionsView from '@/components/TransactionsView'
import ProfileView from '@/components/ProfileView'
import AdminView from '@/components/AdminView'

type Tab = 'discover' | 'list' | 'transactions' | 'profile' | 'admin'

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('discover')

  return (
    <ThemeProvider>
      <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
        <Header activeTab={activeTab} onTabChange={tab => setActiveTab(tab as Tab)} />
        <main>
          {activeTab === 'discover'      && <DiscoverView />}
          {activeTab === 'list'          && <ListPropertyView />}
          {activeTab === 'transactions'  && <TransactionsView />}
          {activeTab === 'profile'       && <ProfileView />}
          {activeTab === 'admin'         && <AdminView />}
        </main>
      </div>
    </ThemeProvider>
  )
}
