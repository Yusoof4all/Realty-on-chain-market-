import { useReadContract, useWriteContract } from 'wagmi'
import { erc20Abi } from 'viem'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { parseAmount, Amount } from '@/onchain-money'

// Contract address — populated after deploy
export const REAL_ESTATE_ADDRESS = (import.meta.env.VITE_CONTRACT_ADDRESS ?? '') as `0x${string}`
export const CHAIN_ID = 5042002 // Arc Testnet

// Minimal ABI — only what the UI needs
export const REAL_ESTATE_ABI = [
  // View
  { name: 'listingCount', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { name: 'getListing', type: 'function', stateMutability: 'view', inputs: [{ name: 'id', type: 'uint256' }], outputs: [{ components: [{ name: 'listingId', type: 'uint256' }, { name: 'owner', type: 'address' }, { name: 'title', type: 'string' }, { name: 'location', type: 'string' }, { name: 'propertyType', type: 'string' }, { name: 'priceUsdc', type: 'uint256' }, { name: 'rentPerMonthUsdc', type: 'uint256' }, { name: 'forSale', type: 'bool' }, { name: 'forRent', type: 'bool' }, { name: 'active', type: 'bool' }, { name: 'createdAt', type: 'uint256' }, { name: 'metadataUri', type: 'string' }], type: 'tuple' }] },
  {
    name: 'users', type: 'function', stateMutability: 'view',
    inputs: [{ name: '', type: 'address' }],
    outputs: [
      { name: 'isKyced', type: 'bool' },
      { name: 'kycLevel', type: 'uint8' },
      { name: 'reputationScore', type: 'uint16' },
      { name: 'totalTransactions', type: 'uint256' },
      { name: 'disputeCount', type: 'uint256' },
      { name: 'isBanned', type: 'bool' },
      { name: 'reviewCount', type: 'uint256' },
    ],
  },
  { name: 'purchaseEscrows', type: 'function', stateMutability: 'view', inputs: [{ name: '', type: 'uint256' }], outputs: [{ name: 'escrowId', type: 'uint256' }, { name: 'listingId', type: 'uint256' }, { name: 'buyer', type: 'address' }, { name: 'seller', type: 'address' }, { name: 'amountUsdc', type: 'uint256' }, { name: 'platformFeeUsdc', type: 'uint256' }, { name: 'state', type: 'uint8' }, { name: 'createdAt', type: 'uint256' }, { name: 'fundedAt', type: 'uint256' }, { name: 'disputeDeadline', type: 'uint256' }] },
  { name: 'rentAgreements', type: 'function', stateMutability: 'view', inputs: [{ name: '', type: 'uint256' }], outputs: [{ name: 'agreementId', type: 'uint256' }, { name: 'listingId', type: 'uint256' }, { name: 'tenant', type: 'address' }, { name: 'landlord', type: 'address' }, { name: 'rentPerMonthUsdc', type: 'uint256' }, { name: 'depositUsdc', type: 'uint256' }, { name: 'platformFeeUsdc', type: 'uint256' }, { name: 'state', type: 'uint8' }, { name: 'startedAt', type: 'uint256' }, { name: 'lastRentPaidAt', type: 'uint256' }, { name: 'monthsPaid', type: 'uint256' }, { name: 'depositReturned', type: 'bool' }] },
  { name: 'claimable', type: 'function', stateMutability: 'view', inputs: [{ name: '', type: 'address' }], outputs: [{ type: 'uint256' }] },
  { name: 'platformFeeBalance', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { name: 'usdcToken', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
  // Write
  { name: 'createListing', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'title', type: 'string' }, { name: 'location', type: 'string' }, { name: 'propertyType', type: 'string' }, { name: 'priceUsdc', type: 'uint256' }, { name: 'rentPerMonthUsdc', type: 'uint256' }, { name: 'forSale', type: 'bool' }, { name: 'forRent', type: 'bool' }, { name: 'metadataUri', type: 'string' }], outputs: [] },
  { name: 'initiatePurchase', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'listingId', type: 'uint256' }], outputs: [] },
  { name: 'fundPurchaseEscrow', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'escrowId', type: 'uint256' }], outputs: [] },
  { name: 'confirmInspection', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'escrowId', type: 'uint256' }], outputs: [] },
  { name: 'completePurchase', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'escrowId', type: 'uint256' }], outputs: [] },
  { name: 'disputePurchase', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'escrowId', type: 'uint256' }], outputs: [] },
  { name: 'initiateRent', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'listingId', type: 'uint256' }], outputs: [] },
  { name: 'payDeposit', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'agreementId', type: 'uint256' }], outputs: [] },
  { name: 'activateRent', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'agreementId', type: 'uint256' }], outputs: [] },
  { name: 'payRent', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'agreementId', type: 'uint256' }], outputs: [] },
  { name: 'terminateRent', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'agreementId', type: 'uint256' }], outputs: [] },
  { name: 'claimFunds', type: 'function', stateMutability: 'nonpayable', inputs: [], outputs: [] },
  { name: 'leaveReview', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'target', type: 'address' }, { name: 'escrowOrAgreementId', type: 'uint256' }, { name: 'isPurchase', type: 'bool' }, { name: 'score', type: 'uint8' }, { name: 'comment', type: 'string' }], outputs: [] },
  { name: 'updateListing', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'listingId', type: 'uint256' }, { name: 'priceUsdc', type: 'uint256' }, { name: 'rentPerMonthUsdc', type: 'uint256' }, { name: 'forSale', type: 'bool' }, { name: 'forRent', type: 'bool' }, { name: 'active', type: 'bool' }], outputs: [] },
  { name: 'verifyWithSignature', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'user', type: 'address' }, { name: 'level', type: 'uint8' }, { name: 'nonce', type: 'uint256' }, { name: 'expiry', type: 'uint256' }, { name: 'sig', type: 'bytes' }], outputs: [] },
  { name: 'kycNonces', type: 'function', stateMutability: 'view', inputs: [{ name: '', type: 'address' }], outputs: [{ type: 'uint256' }] },
  { name: 'kycSigner', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
] as const

export interface ListingData {
  listingId: bigint
  owner: string
  title: string
  location: string
  propertyType: string
  priceUsdc: bigint
  rentPerMonthUsdc: bigint
  forSale: boolean
  forRent: boolean
  active: boolean
  createdAt: bigint
  metadataUri: string
}

export interface UserProfile {
  isKyced: boolean
  kycLevel: number
  reputationScore: number
  totalTransactions: bigint
  disputeCount: bigint
  isBanned: boolean
  reviewCount: bigint
}

export function useListingCount() {
  return useReadContract({
    address: REAL_ESTATE_ADDRESS,
    abi: REAL_ESTATE_ABI,
    functionName: 'listingCount',
    chainId: CHAIN_ID,
    query: { enabled: !!REAL_ESTATE_ADDRESS },
  })
}

export function useListing(id: bigint) {
  return useReadContract({
    address: REAL_ESTATE_ADDRESS,
    abi: REAL_ESTATE_ABI,
    functionName: 'getListing',
    args: [id],
    chainId: CHAIN_ID,
    query: { enabled: !!REAL_ESTATE_ADDRESS && id > 0n },
  })
}

export function useUserProfile(address: `0x${string}` | undefined) {
  const result = useReadContract({
    address: REAL_ESTATE_ADDRESS,
    abi: REAL_ESTATE_ABI,
    functionName: 'users',
    args: [address as `0x${string}`],
    chainId: CHAIN_ID,
    query: { enabled: !!REAL_ESTATE_ADDRESS && !!address },
  })
  // wagmi infers multiple named outputs as a tuple — map to a named object
  const raw = result.data
  const profile: UserProfile | undefined = raw
    ? { isKyced: raw[0], kycLevel: raw[1], reputationScore: raw[2], totalTransactions: raw[3], disputeCount: raw[4], isBanned: raw[5], reviewCount: raw[6] }
    : undefined
  return { ...result, data: profile }
}

export function useClaimable(address: `0x${string}` | undefined) {
  return useReadContract({
    address: REAL_ESTATE_ADDRESS,
    abi: REAL_ESTATE_ABI,
    functionName: 'claimable',
    args: [address as `0x${string}`],
    chainId: CHAIN_ID,
    query: { enabled: !!REAL_ESTATE_ADDRESS && !!address },
  })
}

export function useUsdcAllowance(owner: `0x${string}` | undefined) {
  const usdcFact = getUsdc(CHAIN_ID)
  return useReadContract({
    address: usdcFact?.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'allowance',
    args: [owner as `0x${string}`, REAL_ESTATE_ADDRESS],
    chainId: CHAIN_ID,
    query: { enabled: !!owner && !!usdcFact && !!REAL_ESTATE_ADDRESS },
  })
}

export function useUsdcBalance(address: `0x${string}` | undefined) {
  const usdcFact = getUsdc(CHAIN_ID)
  return useReadContract({
    address: usdcFact?.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: [address as `0x${string}`],
    chainId: CHAIN_ID,
    query: { enabled: !!address && !!usdcFact },
  })
}

export function formatUsdc(raw: bigint): string {
  const amt = Amount.fromRaw(raw, 6)
  return amt.toFixed(2)
}

export function parseUsdc(value: string): bigint {
  return parseAmount(CHAIN_ID, value).raw
}

export function getTxUrl(hash: string) {
  return buildTxExplorerUrl(CHAIN_ID, hash)
}

export function useApproveAndCall() {
  const { writeContractAsync } = useWriteContract()
  const usdcFact = getUsdc(CHAIN_ID)

  const approve = async (amount: bigint) => {
    if (!usdcFact) throw new Error('USDC not found for chain')
    return writeContractAsync({
      address: usdcFact.address as `0x${string}`,
      abi: erc20Abi,
      functionName: 'approve',
      args: [REAL_ESTATE_ADDRESS, amount],
      chainId: CHAIN_ID,
    })
  }

  return { approve }
}

export const ESCROW_STATES = ['Pending', 'Funded', 'Inspection', 'Completed', 'Disputed', 'Refunded'] as const
export const RENT_STATES = ['Pending', 'Deposit Paid', 'Active', 'Terminated', 'Disputed'] as const

export function escrowStateLabel(n: number) { return ESCROW_STATES[n] ?? 'Unknown' }
export function rentStateLabel(n: number) { return RENT_STATES[n] ?? 'Unknown' }
